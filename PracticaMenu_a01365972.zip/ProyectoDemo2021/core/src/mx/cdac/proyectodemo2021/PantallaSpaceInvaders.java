package mx.cdac.proyectodemo2021;

import com.badlogic.gdx.Screen;

public class PantallaSpaceInvaders extends Pantalla {
    private Juego juego;
    public PantallaSpaceInvaders(Juego juego) {
        this.juego=juego;
    }

    @Override
    public void show() {

    }

    @Override
    public void render(float delta) {
        borrarPantalla(0,0,1);

    }

    @Override
    public void pause() {

    }

    @Override
    public void resume() {

    }

    @Override
    public void dispose() {

    }
}
